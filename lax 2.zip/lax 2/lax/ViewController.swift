//
//  ViewController.swift
//  lax
//
//  Created by John Zalubski on 2/3/20.
//  Copyright © 2020 John Zalubski. All rights reserved.
//






import UIKit

class ViewController: UIViewController {
    
    var pic = UIImageView()
    let fight = (0..<10).map { _ in UIImageView() }
    var textEnter = UITextField()
    var g2 = UIPanGestureRecognizer()
    

    
    var slider = UISlider()
    

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fight[0].image  = UIImage(named: "a.png")

        
        fight.forEach{
            $0.isUserInteractionEnabled = true
        }
        [slider,textEnter].forEach{
            $0.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview($0)
            
            
            
            $0.backgroundColor = .blue
        }
        
        slider.backgroundColor = .clear
        
        g2 = UIPanGestureRecognizer(target: self, action: #selector(ViewController.g1Method))
        fight[0].addGestureRecognizer(g2)
        

        
     
        
        
        
        pic.backgroundColor = .clear
        
        pic.backgroundColor = .systemGreen
        fight.forEach{
            $0.backgroundColor = .clear
            view.addSubview($0)
            $0.translatesAutoresizingMaskIntoConstraints = false
        }
        
        
        [pic].forEach{
            
            view.addSubview($0)
            $0.translatesAutoresizingMaskIntoConstraints = false
            
            
        }
        // Do any additional setup after loading the view.
        NSLayoutConstraint.activate ([
            
            pic.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant :0),
            pic.topAnchor.constraint(equalTo: fight[0].bottomAnchor, constant : 0),

            pic.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.62, constant: 0),
            pic.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0),


            
            textEnter.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant :0),
            textEnter.topAnchor.constraint(equalTo: view.topAnchor, constant : 0),
            textEnter.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1, constant: 0),
            textEnter.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0),
            
//
            fight[0].trailingAnchor.constraint(equalTo: view.trailingAnchor, constant :0),
            fight[0].topAnchor.constraint(equalTo: textEnter.bottomAnchor, constant : 0),

            fight[0].heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.10, constant: 0),
            fight[0].widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.10, constant: 0),
            fight[0].leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0),




  
//
//
//
//


            slider.topAnchor.constraint(equalTo: pic.bottomAnchor, constant : 0),

            slider.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.08, constant: 0),
            slider.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1, constant: 0),
            slider.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0),


            
            
            
            
        ])
        textEnter.textAlignment = .center
        
        self.view.sendSubviewToBack(pic)
        
    }
    
    @objc func g1Method(_ sender: UIPanGestureRecognizer){
        
        
        let tranistioon = sender.translation(in: self.view)
        sender.view!.center = CGPoint(x: sender.view!.center.x + tranistioon.x, y: sender.view!.center.y + tranistioon.y)
        sender.setTranslation(CGPoint.zero,in: self.view)    }
    
    
    
}


